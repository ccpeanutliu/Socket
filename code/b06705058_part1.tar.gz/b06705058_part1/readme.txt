1.  進入此資料夾下, 在command輸入make可以編譯出client.out檔案
    或是使用g++編譯：g++ client.cpp -o client.out

2.  輸入make clean可以刪除client.out

3.  執行client.out的方式: ./client.out <ip> <port>

4.  測試執行環境為: ubuntu18.04